<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Email </title>
</head>
<body style="font-family: 'Trebuchet MS'" >
    <h3>Pemberitahuan Biaya penggunaan perjalanan dinas hampir mencapai anggaran</h3>
    <p>Anggaran yang ditentukan adalah sebesar Rp <b>{{number_format($limit, '0', ',', '.')}}</b> </p>
    <p>Penggunaan telah mencapai Rp <b>{{number_format($biaya, '0', ',', '.')}}</b> </p>
    <p>Harap dilakukan topup agar perjalanan dinas dapat dilakukan</p>
    
</body>
</html>